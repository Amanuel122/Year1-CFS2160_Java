package CheckoutSystem.CashOnly;

import static org.junit.jupiter.api.Assertions.*;

class CheckoutControllerTest {
    CheckoutController ab;
    @org.junit.jupiter.api.Test
    void getTotalRaised() {
        ab = new CheckoutController();
        
    }
}