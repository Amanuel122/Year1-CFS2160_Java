package CheckoutSystem.CardOnly;

import CheckoutSystem.main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.control.Button;


public class  LoadingScreenController  {


    @FXML
   public void initialize() {

    }


}







